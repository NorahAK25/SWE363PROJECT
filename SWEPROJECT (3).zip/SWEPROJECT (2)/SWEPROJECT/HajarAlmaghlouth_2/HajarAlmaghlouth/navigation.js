
document.addEventListener("DOMContentLoaded", () => {
    setupMenuNavigation();
    setupEditAndSaveActions();
    setupProfileView();
    setupNavigationArrows();
  });
  
  const pageHistory = [];  
  let forwardHistory = []; 
  let currentPage = window.location.href;  
  
  function navigateTo(page) {
    if (page !== currentPage) {
      pageHistory.push(currentPage);  
      forwardHistory = [];  
      currentPage = page;
      window.location.href = currentPage;
    }
  }
  
  function setupMenuNavigation() {
    document.querySelectorAll(".menu-item").forEach((item) => {
      item.addEventListener("click", (event) => {
        const pageName = event.currentTarget.querySelector("span").textContent.trim();
        switch (pageName) {
          case "Students Orders":
            navigateTo("index.html");
            break;
          case "Faculty Orders":
            navigateTo("index4.html");
            break;
          case "Late Fees":
            navigateTo("index6.html");
            break;
          default:
            console.error("Unknown page:", pageName);
        }
      });
    });
  }
  
  function setupEditAndSaveActions() {
    document.body.addEventListener("click", (event) => {
      if (event.target.classList.contains("edit-button")) {
        
        if (currentPage.includes("index.html")) {
          navigateTo("index2.html");  
        } else if (currentPage.includes("index4.html")) {
          navigateTo("index3.html");  
        }
      } else if (event.target.classList.contains("save-button")) {
        
        if (currentPage.includes("index2.html")) {
          navigateTo("index.html");  
        } else if (currentPage.includes("index3.html")) {
          navigateTo("index4.html");  
        }
      }
    });
  }
  
  function setupProfileView() {
    
    const profileElements = [document.querySelector(".user-info h2"), document.querySelector(".logo-container")];
    profileElements.forEach((element) => {
      if (element) {
        element.addEventListener("click", () => {
          navigateTo("index5.html");
        });
      }
    });
  }
  
  function setupNavigationArrows() {
    
    document.querySelector(".nav-arrows .nav-button:first-child").addEventListener("click", () => {
      if (pageHistory.length > 0) {
        forwardHistory.push(currentPage);  
        const lastPage = pageHistory.pop();  
        currentPage = lastPage;
        window.location.href = currentPage;
      }
    });
  
    
    document.querySelector(".nav-arrows .nav-button:last-child").addEventListener("click", () => {
      if (forwardHistory.length > 0) {
        pageHistory.push(currentPage);  
        const nextPage = forwardHistory.pop();  
        currentPage = nextPage;
        window.location.href = currentPage;
      }
    });
  }
