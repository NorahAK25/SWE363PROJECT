const express = require('express');
const router = express.Router();
const {
    getAllBooks,
    addBook,
    getBookById,
    updateBookById,
    deleteBookById,
    approveBook,
    rejectBookById
} = require('../controllers/bookController');

router.get('/', getAllBooks);        // Corrected route for all books
router.post('/', addBook);           // Corrected route for adding a book
router.get('/:id', getBookById);    // Get a book by ID
router.put('/:id', updateBookById); // Update book by ID
router.delete('/:id', deleteBookById); // Delete book by ID
router.put('/approve/:id', approveBook); // Approve book
router.delete('/reject/:id', rejectBookById); // Reject book

module.exports = router;
