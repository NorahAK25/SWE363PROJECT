const express = require('express');
const { getAllRoles, getRoleByName } = require('../controllers/roleController');

const router = express.Router();

// Define routes
router.get('/', getAllRoles);
router.get('/:name', getRoleByName);

module.exports = router;
