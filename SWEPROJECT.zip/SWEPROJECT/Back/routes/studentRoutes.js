const express = require('express');
const StudentOrder = require('../models/Studen-order.js');
const router = express.Router();

// GET all student orders
router.get('/', async (req, res) => {
  try {
    const orders = await StudentOrder.find()
      .populate('student_id')
      .populate('book_id');
    res.json(orders);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// GET orders that need approval (status: active)
router.get('/pending-approval', async (req, res) => {
  try {
    const pendingOrders = await StudentOrder.find({ status: 'active' })
      .populate('student_id')
      .populate('book_id');
    res.json(pendingOrders);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// GET orders for a specific student
router.get('/student/:studentId', async (req, res) => {
  try {
    const orders = await StudentOrder.find({ student_id: req.params.studentId })
      .populate('book_id');
    res.json(orders);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// POST a new student order
router.post('/', async (req, res) => {
  const order = new StudentOrder({
    student_id: req.body.student_id,
    book_id: req.body.book_id,
    status: req.body.status,
    date: req.body.date
  });

  try {
    const newOrder = await order.save();
    res.status(201).json(newOrder);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE a student order
router.delete('/:orderId', async (req, res) => {
  try {
    const order = await StudentOrder.findById(req.params.orderId);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    await order.remove();
    res.json({ message: 'Order deleted' });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PATCH to approve/reject an order
router.patch('/:orderId', async (req, res) => {
  try {
    const updatedOrder = await StudentOrder.findByIdAndUpdate(
      req.params.orderId,
      { status: req.body.status }, // Accept "active" or "inactive" as status
      { new: true }
    );

    if (!updatedOrder) {
      return res.status(404).json({ message: 'Order not found' });
    }

    res.json(updatedOrder);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
