const express = require('express');
const FacultyOrder = require('../models/Borrowing');
const router = express.Router();

// GET all faculty orders
router.get('/', async (req, res) => {
  try {
    const orders = await FacultyOrder.find(req.query);  // Find orders based on query params
    res.json(orders);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// POST new faculty order
router.post('/', async (req, res) => {
  // Ensure all necessary fields are present and create the borrowing entry
  const order = new FacultyOrder({
    user_id: req.body.user_id,  // Mongo ObjectId of the user
    book_id: req.body.book_id,  // Mongo ObjectId of the book
    borrow_date: req.body.date || Date.now(),  // Optional: Set to current date if no date provided
    return_date: req.body.return_date || null,  // Optional: Specify return date if available
    status: req.body.status || 'Borrowed'  // Default to 'Borrowed' if no status provided
  });

  try {
    const newOrder = await order.save();  // Save the new borrowing order
    res.status(201).json(newOrder);  // Send back the created order as a response
  } catch (err) {
    res.status(400).json({ message: err.message });  // Handle any errors that occur during saving
  }
});

module.exports = router;
