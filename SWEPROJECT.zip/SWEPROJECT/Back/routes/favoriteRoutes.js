const express = require('express');
const Favorite = require('../models/Favorite');
const router = express.Router();

// GET all favorites (to list the favorite books of all users)
router.get('/', async (req, res) => {
  try {
    const favorites = await Favorite.find().populate('user_id').populate('book_id');
    res.json(favorites);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// GET favorites for a specific user
router.get('/user/:userId', async (req, res) => {
  try {
    const favorites = await Favorite.find({ user_id: req.params.userId }).populate('book_id');
    res.json(favorites);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// POST a new favorite (user marking a book as favorite)
router.post('/', async (req, res) => {
  const favorite = new Favorite({
    user_id: req.body.user_id,
    book_id: req.body.book_id
  });

  try {
    const newFavorite = await favorite.save();
    res.status(201).json(newFavorite);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE a favorite (removing a book from a user's favorites)
router.delete('/:favoriteId', async (req, res) => {
  try {
    const favorite = await Favorite.findById(req.params.favoriteId);
    if (!favorite) {
      return res.status(404).json({ message: 'Favorite not found' });
    }

    await favorite.remove();
    res.json({ message: 'Favorite removed' });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
