const jwt = require('jsonwebtoken');

// In-memory array to store blacklisted tokens
let blacklistedTokens = [];  // In production, consider using Redis or a database

// Authorization middleware to check for token and blacklist
const authMiddleware = (req, res, next) => {
    const token = req.header('x-auth-token');
    if (!token) {
        return res.status(401).json({ error: 'No token, authorization denied' });
    }

    // Check if the token is blacklisted
    if (blacklistedTokens.includes(token)) {
        return res.status(401).json({ error: 'Token has been blacklisted, please log in again' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded.userId; // Attach user ID to the request object
        next();
    } catch (err) {
        res.status(401).json({ error: 'Token is not valid' });
    }
};

// Logout route to blacklist the token
const logout = (req, res) => {
    const token = req.header('x-auth-token');
    if (token) {
        // Add the token to the blacklist
        blacklistedTokens.push(token); 
    }
    res.status(200).json({ message: 'User logged out successfully' });
};

module.exports = { authMiddleware, logout };
