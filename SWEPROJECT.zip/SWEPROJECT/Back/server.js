const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const userRoutes = require('./routes/userRoutes');   
const bookRoutes = require('./routes/bookRoutes');   
const facultyRoutes = require('./routes/facultyRoutes'); 
const studentOrderRoutes = require('./routes/studentRoutes.js');
const roleRoutes = require('./routes/roleRoutes');  
const cors = require('cors');

const favoriteRoutes = require('./routes/favoriteRoutes');  

// Initialize app
const app = express();

// Load environment variables before using them
dotenv.config(); // Ensure this line is at the top of the file

// Middleware
app.use(express.json()); // Parse incoming JSON data

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log('MongoDB connection error:', err));
    app.use(cors({ origin: 'http://127.0.0.1:5500' }));

// Routes
app.use('/api/users', userRoutes); // Register user routes
app.use('/api/books', bookRoutes); // Register book routes
app.use('/api/faculty', facultyRoutes);
app.use('/api/favorites', favoriteRoutes);  
app.use('/api/student-orders', studentOrderRoutes);
app.use('/api/roles', roleRoutes); 

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
