const Role = require('../models/Role'); // Import Role model

// Fetch all roles
exports.getAllRoles = async (req, res) => {
    try {
        const roles = await Role.find(); // Fetch all roles from the database
        res.status(200).json({ roles });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch roles', details: error.message });
    }
};

// Fetch a role by name
exports.getRoleByName = async (req, res) => {
    const { name } = req.params;
    try {
        const role = await Role.findOne({ name }); // Find a role by name
        if (!role) {
            return res.status(404).json({ error: 'Role not found' });
        }
        res.status(200).json({ role });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch role', details: error.message });
    }
};

// Create a new role
exports.createRole = async (req, res) => {
    const { name } = req.body;
    try {
        const existingRole = await Role.findOne({ name });
        if (existingRole) {
            return res.status(400).json({ error: 'Role already exists' });
        }
        const newRole = new Role({ name });
        await newRole.save();
        res.status(201).json({ message: 'Role created successfully', role: newRole });
    } catch (error) {
        res.status(500).json({ error: 'Failed to create role', details: error.message });
    }
};

// Delete a role
exports.deleteRole = async (req, res) => {
    const { id } = req.params;
    try {
        const role = await Role.findByIdAndDelete(id); // Delete role by ID
        if (!role) {
            return res.status(404).json({ error: 'Role not found' });
        }
        res.status(200).json({ message: 'Role deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete role', details: error.message });
    }
};
