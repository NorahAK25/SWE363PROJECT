//bookCOntroller.js
const Book = require('../models/Book');

// Add a new book
exports.addBook = async (req, res) => {
    const { title, author, isbn, category } = req.body;
    try {
        const newBook = new Book({
            title,
            author,
            isbn,
            category,
            availability: false,  // Default to false until admin approval
            admin_approved: false // Default to false until admin approves
        });

        await newBook.save();
        res.status(201).json({ message: 'Book added successfully', book: newBook });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Get all books
// eslint-disable-next-line @typescript-eslint/no-unused-vars
exports.getAllBooks = async (req, res) => {
    try {
        const books = await Book.find();
        if (books.length === 0) {
            return res.status(404).json({ message: 'No books found' });
        }
        res.status(200).json({ books });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};


// Get book by ID
exports.getBookById = async (req, res) => {
    const { id } = req.params;
    try {
        const book = await Book.findById(id);
        if (!book) {
            return res.status(404).json({ error: 'Book not found' });
        }
        res.status(200).json({ book });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// // Update book by ID
// exports.updateBookById = async (req, res) => {
//     const { id } = req.params;
//     const { title, author, isbn, category, availability } = req.body;
//     try {
//         const updatedBook = await Book.findByIdAndUpdate(id, {
//             title,
//             author,
//             isbn,
//             category,
//             availability
//         }, { new: true });

//         if (!updatedBook) {
//             return res.status(404).json({ error: 'Book not found' });
//         }
//         res.status(200).json({ message: 'Book updated successfully', updatedBook });
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };
exports.updateBookById = async (req, res) => {
    const { id } = req.params;
    const { title, author, isbn, category, availability } = req.body;
    try {
        const updatedBook = await Book.findByIdAndUpdate(id, {
            title,
            author,
            isbn,
            category,
            availability
        }, { new: true });

        if (!updatedBook) {
            return res.status(404).json({ error: 'Book not found' });
        }
        res.status(200).json({ message: 'Book updated successfully', updatedBook });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};


// Delete book by ID
exports.deleteBookById = async (req, res) => {
    const { id } = req.params;
    try {
        const deletedBook = await Book.findByIdAndDelete(id);
        if (!deletedBook) {
            return res.status(404).json({ error: 'Book not found' });
        }
        res.status(200).json({ message: 'Book deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Approve a book (set availability to true)
exports.approveBook = async (req, res) => {
    const { id } = req.params;
    try {
        const book = await Book.findById(id);
        if (!book) {
            return res.status(404).json({ error: 'Book not found' });
        }

        // Set availability to true and mark as approved
        book.availability = true;
        book.admin_approved = true;

        await book.save();
        res.status(200).json({ message: 'Book approved successfully', book });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Reject a book (set admin_approved to false)
// Reject book by ID (Delete it)
exports.rejectBookById = async (req, res) => {
    const { id } = req.params;
    try {
        // Try to find the book by ID and delete it
        const deletedBook = await Book.findByIdAndDelete(id);
        if (!deletedBook) {
            return res.status(404).json({ error: 'Book not found' });
        }
        res.status(200).json({ message: 'Book rejected and deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
 