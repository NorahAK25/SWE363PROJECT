//models/studen-order.js
const mongoose = require('mongoose');

const studentOrderSchema = new mongoose.Schema({
    student_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    book_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Book', required: true },
    status: { type: String, enum: ['active', 'inactive'], default: 'active' },
    date: { type: Date, default: Date.now }
});

const StudentOrder = mongoose.model('StudentOrder', studentOrderSchema);
module.exports = StudentOrder;
