const mongoose = require('mongoose');

const problemSchema = new mongoose.Schema({
    student_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String },
    description: { type: String },
    status: { type: String, enum: ['resolved', 'unresolved'], default: 'unresolved' },
    created_at: { type: Date, default: Date.now }
});

const Problem = mongoose.model('Problem', problemSchema);
module.exports = Problem;
