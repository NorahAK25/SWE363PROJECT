const mongoose = require('mongoose');

const borrowingSchema = new mongoose.Schema({
    book_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Book', required: true },
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    borrow_date: { type: Date, default: Date.now },
    return_date: { type: Date },
    status: { type: String, enum: ['Borrowed', 'Returned'], default: 'Borrowed' }
});

const Borrowing = mongoose.model('Borrowing', borrowingSchema);
module.exports = Borrowing;
