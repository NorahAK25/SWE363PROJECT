
document.addEventListener("DOMContentLoaded", () => {
    setupMenuNavigation();
    setupEditAndSaveActions();
    setupProfileView();
    setupNavigationArrows();
  });
  
  const pageHistory = [];  
  let forwardHistory = []; 
  let currentPage = window.location.href;  
  
  function navigateTo(page) {
    if (page !== currentPage) {
      pageHistory.push(currentPage);  
      forwardHistory = [];  
      currentPage = page;
      window.location.href = currentPage;
    }
  }
  
  function setupMenuNavigation() {
    document.querySelectorAll(".menu-item").forEach((item) => {
      item.addEventListener("click", (event) => {
        const pageName = event.currentTarget.querySelector("span").textContent.trim();
        switch (pageName) {
          case "Manage Books":
            navigateTo("manageBooks.html");
            break;
            case "Manage orders":
            navigateTo("manageStudentsOrders.html");
            break;
          case "Students Orders":
            navigateTo("studentOrders.html");
            break;
          case "Faculty Orders":
            navigateTo("facultyOrders.html");
            break;
          case "Late Fees":
            navigateTo("lateFees.html");
            break;
          default:
            console.error("Unknown page:", pageName);
        }
      });
    });
  }
  
  function setupEditAndSaveActions() {
    document.body.addEventListener("click", (event) => {
      if (event.target.classList.contains("edit-button")) {
        
        if (currentPage.includes("index.html")) {
          navigateTo("manageStudentsOrders.html");  
        } else if (currentPage.includes("index4.html")) {
          navigateTo("Admin\manageBooks.html");  
        }
      } else if (event.target.classList.contains("save-button")) {
        
        if (currentPage.includes("manageStudentsOrders.html")) {
          navigateTo("index.html");  
        } else if (currentPage.includes("Admin\manageBooks.html")) {
          navigateTo("index4.html");  
        }
      }
    });
  }
  
  function setupProfileView() {
    
    const profileElements = [document.querySelector(".user-info h2"), document.querySelector(".logo-container")];
    profileElements.forEach((element) => {
      if (element) {
        element.addEventListener("click", () => {
          navigateTo("userInfo.html");
        });
      }
    });
  }
  
  function setupNavigationArrows() {
    
    document.querySelector(".nav-arrows .nav-button:first-child").addEventListener("click", () => {
      if (pageHistory.length > 0) {
        forwardHistory.push(currentPage);  
        const lastPage = pageHistory.pop();  
        currentPage = lastPage;
        window.location.href = currentPage;
      }
    });
  
    
    document.querySelector(".nav-arrows .nav-button:last-child").addEventListener("click", () => {
      if (forwardHistory.length > 0) {
        pageHistory.push(currentPage);  
        const nextPage = forwardHistory.pop();  
        currentPage = nextPage;
        window.location.href = currentPage;
      }
    });
  }
